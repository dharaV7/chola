
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:rough9/firebase_options.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:xml/xml.dart' as xml;
import 'package:flutter/services.dart' show rootBundle;


void main() async{
  
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(MaterialApp(
  home: Home(),
  
));}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {


  String _scanBarcode = 'Unknown';
  
  String Name ='';
  String state ='';
  String yob='';
  String AadhaarNumber= '';

   @override
  void initState() {
    super.initState();
   
  }

  Future<void> scanQR() async {
    String barcodeScanRes;
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
        '#ff6666',
        'Cancel',
        true,
        ScanMode.QR,
      );
      print(barcodeScanRes);

      if (barcodeScanRes != '-1') {
    
        xml.XmlDocument document = xml.XmlDocument.parse(barcodeScanRes);
        xml.XmlElement rootElement = document.rootElement;

        String name = rootElement.getAttribute('name') ?? '';
        String yob = rootElement.getAttribute('yob') ?? '';
        String aadhaarNumber = rootElement.getAttribute('uid') ?? '';
        String state = rootElement.getAttribute('state') ?? '';

        setState(() {
          namecontroller.text = name;
          phonecontroller.text = yob;
          aadhaarcontroller.text = aadhaarNumber;
          statecontroller.text = state;
        });
      
    }
  } on PlatformException {
    barcodeScanRes = 'Failed to get platform version.';
  }

  setState(() {
    _scanBarcode = barcodeScanRes;
  });
}

String _extractXmlString(String barcodeData) {
  RegExp regExp = RegExp(r'<\?xml[^>]+>(.+)</PrintLetterBarcodeData>', multiLine: true);
  Match? match = regExp.firstMatch(barcodeData);

  return match?.group(1) ?? '';
}

  createdata(){
    print('created');

  

    DocumentReference documentReference  = FirebaseFirestore.instance.collection('detailsform').doc(aadhaarcontroller.text);

    Map<String, dynamic> details = {
      "Name":namecontroller.text,
      "AadhaarNumber": aadhaarcontroller.text,
      "yob": phonecontroller.text,
      "state": statecontroller.text,
      
    };

      if(details['AadhaarNumber'].isEmpty){
      print("Enter Valid Aadhaar Number");
      return;
    }
  
    documentReference.set(details).whenComplete((){
      print("${aadhaarcontroller.text} created");
    });

  }

  getname(Name){
    this.Name = Name;
  }

  getaadhaarnumber(AadhaarNumber){
    this.AadhaarNumber = AadhaarNumber;
  }

  getyob(yob){
    this.yob = yob;
  }

  getstate(state){
    this.state = state;
  }

 
  final detailsFormkey = GlobalKey<FormState>();
  final phonecontroller = TextEditingController();
  final aadhaarcontroller = TextEditingController();
  final statecontroller = TextEditingController();
  
  final namecontroller = TextEditingController();





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white,
        title: Image.asset(
          'assets/cholalogo.jpg',
          fit: BoxFit.contain,
          height: 50,
        ),
      ),
      body:  
      SingleChildScrollView(
        child: Column(
          children: [
            Center(
              child: Container(
                color: Colors.indigo[900],
                height: 50.0,
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(110.0, 13.0, 5.0, 10.0),
                child: const Text(
                  'Customer Details -2',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
        
            const Divider(
              color: Colors.red,
              height: 0,
              thickness: 2,
              indent: 0,
              endIndent: 0,
            ),
        
            
            Center(
              child: Container(
                height: 500.0,
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 50, 20, 30),
                color: Colors.white,
                child: Form(
                  
                  key: detailsFormkey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Expanded(
                              child: 
                              TextFormField(
                                controller: aadhaarcontroller,
                                decoration: const InputDecoration(
                                
                                  icon: Icon(Icons.credit_card_rounded),
                                  hintText: 'Enter Aadhaar Number',
                                  labelText: 'Aadhaar Number',
                                  border: OutlineInputBorder(),
                                ),
                                validator: (value) {
                                  
                                  if (value!.isEmpty) {
                                    return 'Aadhaar Number is required';
                                  } else if(value.length<12){
                                    return '12 numbers are required';
                                  }
                                  return null;
                                
                                },
                                onChanged: (String aadhaar) {
                                  getaadhaarnumber(aadhaar);
                                },),
                            ),

                            SizedBox(height: 25.0),
                            Expanded(
                              child: TextFormField(
                                
                                controller: namecontroller,
                                decoration: const InputDecoration(
                                  icon: Icon(Icons.person),
                                  hintText: 'Enter Full Name',
                                  labelText: 'Full Name',
                                  border: OutlineInputBorder(),
                                  
                                ),
                                
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Full Name is required';
                                  } 
                                  return null;
                                },
                                onChanged: (String name) {
                                  getname(name);
                                },
                              ),
                            ),
                              
                            SizedBox(height: 25.0), 
                            Expanded(
                              child: TextFormField(
                                
                                controller: phonecontroller,
                                decoration: const InputDecoration(
                                  icon: Icon(Icons.calendar_month),
                                  hintText: 'Enter Year of Birth',
                                  labelText: 'Birth Year',
                                  border: OutlineInputBorder(),
                                  
                                ),
                                
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Year of Birth is required';
                                  } else if(value.length<4){
                                    return 'Enter Valid Birth Year';
                                  }
                                  return null;
                                },
                                onChanged: (String yob) {
                                  getyob(yob);
                                },
                              ),
                            ),
                              
                            SizedBox(height: 25.0),
                            Expanded(
                              child: TextFormField(
                                
                                controller: statecontroller,
                                decoration: const InputDecoration(
                                  icon: Icon(Icons.home_rounded),
                                  hintText: 'Enter Your State',
                                  labelText: 'State',
                                  border: OutlineInputBorder(),
                                  
                                ),
                                
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'State is required';
                                  }
                                  return null;
                                },
                                onChanged: (String state) {
                                  getstate(state);
                                },
                              ),
                            ),
                              
                            
                            
                            Center(
                              
                              child: Container(
                                
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.lightBlue[800],
                                  ),
                                  
                                  child: const Text('Submit'),
                                  onPressed: () {
                                    
                                    
                                    print("button pressed");
                                    print("debug init");

                                   
                                    if (detailsFormkey.currentState!.validate()) {
                                    createdata();
                                    
                                    showDialog(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                      title: Text('Submitted'),
                                      content: Text('Form submitted successfully!'),
                                      actions: [
                                        TextButton(
                                           onPressed: () {
                                              Navigator.pop(context);
                                            },
                                          child: Text('OK'),
                                        ),
                                      ],
                                    ),
                                  );
                                    }
                                  },
                                ),
                              ),
                            ),

                

                              
                                  ]
                                  ),
                      ),
                    ),
            ),

            const Center(
                heightFactor: 2.5,
                
                child: Text(
                  'OR',
                  style: TextStyle(fontSize: 20),
                  selectionColor: Colors.black,
                ),
                             ),
              
              
              ElevatedButton(
                
                style: ElevatedButton.styleFrom(
                backgroundColor: Colors.lightBlue[800],
                ),
                child: Text('Scan Aadhaar QR'),
                onPressed: () {
                  scanQR();
                },
                
              )

              ]
              ),
      )
      );

  }
}