// import packages

import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

// To run the app
void main() {
  runApp(
    const MaterialApp(
      home: WebViewApp(),
    ),
  );
}


// stateful widget class WebViewApp defined

class WebViewApp extends StatefulWidget {
  const WebViewApp({Key? key}) : super(key: key);

  @override
  State<WebViewApp> createState() => _WebViewAppState();
}

class _WebViewAppState extends State<WebViewApp> {

// declaration of variables 
  
  late final WebViewController controller; //controller for webview
  Offset? _initialSwipePosition; //initial swipe position for gesturedetector
  

 // initialization of webview

  @override
  void initState() {
    super.initState();
    controller = WebViewController() 
      ..loadRequest(
        Uri.parse('https://tjdev10.chola.murugappa.com'), // url to load when app starts
        
        // Initial webview
        headers: {
        'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), interest-cohort=()',
      },
      );
    
      controller.setJavaScriptMode(JavaScriptMode.unrestricted);
      
  }

// Code snippet for Alertdialog on swipe gesture

 void showSwipeDialog() {
  bool isEditing = false; // Track the edit mode
  TextEditingController _urlEditingController = TextEditingController();
  controller.currentUrl().then((url) {                     // to get current url
    _urlEditingController.text = url?.toString() ?? '';
  });
  showDialog(
    context: context,
    builder: (_) {
       return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return AlertDialog(
            title: const Text('Edit URL'),
            content: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _urlEditingController,
                    enabled: isEditing,  // Enable/disable editing based on the edit mode
                    decoration: const InputDecoration(
                      hintText: 'Enter a URL',
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    setState(() {
                      isEditing = !isEditing; // Toggle the edit mode
                    });
                  },
                  icon: const Icon(Icons.edit),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  if (_urlEditingController.text.isNotEmpty) {
                    setState(() {
                      controller.loadRequest(Uri.parse(_urlEditingController.text)); // load new url entered
                      Navigator.pop(context);
                    });
                  } else {
                    Navigator.pop(context);
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          );
        },
      );
    },
  );
}

// To handle the swipe initialization

void handleSwipeUpdate(DragUpdateDetails details) {
  final currentPosition = details.globalPosition;
  if (_initialSwipePosition == null) {
    _initialSwipePosition = currentPosition;
  } else {
    final dx = currentPosition.dx - _initialSwipePosition!.dx;
    if (dx > 100 && details.delta.dy.abs() < 50) {
      // Check if the current URL matches the desired URL
      controller.currentUrl().then((url) {
        if (url?.toString() == 'https://tjdev10.chola.murugappa.com/'  || url?.toString() == 'https://tjdev10.chola.murugappa.com/login') {
          showSwipeDialog();
        }
      });
    }
  }
}


  //To handle the end of the swipe

  void handleSwipeEnd(DragEndDetails details) {
    _initialSwipePosition = null;
  }


// build method 

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height; //adjust screen height
    return Scaffold(
      body: SafeArea( //to not display app over notification bar
        child: SizedBox(
          height: screenHeight,
          child: GestureDetector( // detect gesture
            behavior: HitTestBehavior.translucent,
          onHorizontalDragUpdate: handleSwipeUpdate,
          onHorizontalDragEnd: handleSwipeEnd,
          child: NotificationListener<OverscrollIndicatorNotification>(
              onNotification: (notification) {
                notification.disallowGlow(); // Disable overscroll glow effect
                return true;
              },
            child: SizedBox(
              height: screenHeight,
              child: WebViewWidget(
                controller: controller,
                gestureRecognizers: Set()
                ..add(Factory<VerticalDragGestureRecognizer>( // for scrolling gesture
                    () => VerticalDragGestureRecognizer())),
                
                ),
            )
          ),
        ),
      ),
    ),
    );
  }
}
