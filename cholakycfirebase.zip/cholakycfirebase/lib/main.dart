import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:photo_view/photo_view.dart';



void main() async { 
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  
  runApp(MaterialApp(
  home: MyApp(),
));
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final detailformkey = GlobalKey<FormState>();
  File? _image;
  File? _image1;
  String? panCardDownloadUrl;
  String? aadhaarCardDownloadUrl;


void _openImagepan(File? imageFile) {
  if (imageFile != null) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PhotoView(
          imageProvider: FileImage(imageFile),
        ),
      ),
    );
  } else {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text('Failed to open the image.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
}

void _openImageaadhaar(File? imageFile) {
  if (imageFile != null) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PhotoView(
          imageProvider: FileImage(imageFile),
        ),
      ),
    );
  } else {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text('Failed to open the image.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
}


  
  Future<void> _getImage(ImageSource source, String cardType) async {
    final pickedImage = await ImagePicker().pickImage(source: source, imageQuality: 50);
    if (pickedImage != null) {
      setState(() {
        if (cardType == 'pan') {
          _image = File(pickedImage.path);
          
        } else if (cardType == 'aadhaar') {
          _image1 = File(pickedImage.path);
          
        }
      });
    }
  }

  Future <void> _performLogin() async {
    if (detailformkey.currentState!.validate()) {
      if (_image == null) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Upload Pan Card Photo'),
            content: Text('Please upload Pan Card photo.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _getImage(ImageSource.gallery, 'pan');
                },
                child: Text('Gallery'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _getImage(ImageSource.camera, 'pan');
                },
                child: Text('Camera'),
              ),
            ],
          ),
        );
      } else if(_image1 == null){
        showDialog(context: context,
        builder: (context) => AlertDialog(
          title: Text('Upload Aadhaar Card Photo'),
          content: Text('Please upload Aadhaar Card Photo'),
          actions: [
            TextButton(
              onPressed: (){
                Navigator.pop(context);
                _getImage(ImageSource.gallery, 'aadhaar');
              },
              child: Text('Gallery'),
            ),
            TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _getImage(ImageSource.camera, 'aadhaar');
                },
                child: Text('Camera'),
              ),
          ],
        ), 
        );
      } else {
      // Both images are available, proceed with upload
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Uploading...'),
          content: Text('Please wait while the images are being uploaded.'),
        ),
      );

      try {
        // Upload Pan Card image
       final panCardImageRef = FirebaseStorage.instance.ref().child('pan_card.jpg');
        final panCardUploadTask = panCardImageRef.putFile(_image!);
        final panCardSnapshot = await panCardUploadTask.whenComplete(() => null);
        panCardDownloadUrl = await panCardImageRef.getDownloadURL();

        // Upload Aadhaar Card image
       final aadhaarCardImageRef = FirebaseStorage.instance.ref().child('aadhaar_card.jpg');
        final aadhaarCardUploadTask = aadhaarCardImageRef.putFile(_image1!);
        final aadhaarCardSnapshot = await aadhaarCardUploadTask.whenComplete(() => null);
        aadhaarCardDownloadUrl = await aadhaarCardImageRef.getDownloadURL();

        // Images uploaded successfully
        Navigator.pop(context); // Close the uploading dialog

        

        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Submitted'),
            content: Text('Form submitted successfully!'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('OK'),
              ),
            ],
          ),
        );

        // TODO: Save the download URLs to Firebase Firestore or perform any other desired actions

      } catch (error) {
        // Error occurred during upload
        Navigator.pop(context); // Close the uploading dialog

        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Upload Failed'),
            content: Text('An error occurred while uploading the images. Please try again.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
  }
    }
      
    }
  
 
  @override
  Widget build(BuildContext context) {
          return Scaffold(
            
          appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.white,
          title: Image.asset(
            'assets/cholalogo.jpg',
            fit: BoxFit.contain,
            height: 50,
          ),
        ),
        body: 
         SingleChildScrollView(
          
          child: Column(
          
          children: [
            Container(
              color: Colors.indigo[900],
              height: 50.0,
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(110, 13.0, 5.0, 10.0),
              child: const Text(
                'KYC',
                
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                ),
              ),
            ),
            
            const Divider(
              color: Colors.red,
              height: 0,
              thickness: 2,
              indent: 0,
              endIndent: 0,
            ),
           
            SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 100, 20, 30),
               child: Column(children: [

                const Text(
                  'Pan Card',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10),
                GestureDetector(
                  onTap: (){
                    _openImagepan(_image);
                  },
                  child: _image != null
                          ? Container(
                              width: 160,
                              height: 160,
                              decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: FileImage(_image!) as ImageProvider<Object>,
                                ),
                              ),
                            )
                          : ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.lightBlue[800],
                                padding: EdgeInsets.all(16.0),
                              ),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: Text('Choose an option'),
                                    content: SingleChildScrollView(
                                      child: ListBody(
                                        children: [
                                          GestureDetector(
                                            child: Text('Camera'),
                                            onTap: () {
                                              _getImage(ImageSource.camera, 'pan');
                                              Navigator.pop(context);
                                            },
                                          ),
                                          SizedBox(height: 20),
                                          GestureDetector(
                                            child: Text('Gallery'),
                                            onTap: () {
                                              _getImage(ImageSource.gallery, 'pan');

                                              Navigator.pop(context);
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            
                            
                              icon: Icon(Icons.file_upload),
                              label: Text('Upload Pan Card'),
                            ),
                  
                ),

                SizedBox(height: 70),
                  const Text(
                  'Aadhaar Card',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10),
                GestureDetector(
                  onTap: (){
                    _openImageaadhaar(_image1);
                  },
                  child: _image1 != null
                          ? Container(
                              width: 160,
                              height: 160,
                              decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: FileImage(_image1!) as ImageProvider<Object>,
                                ),
                              ),
                            )
                          : ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.lightBlue[800],
                                padding: EdgeInsets.all(16.0),
                              ),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: Text('Choose an option'),
                                    content: SingleChildScrollView(
                                      child: ListBody(
                                        children: [
                                          GestureDetector(
                                            child: Text('Camera'),
                                            onTap: () {
                                              _getImage(ImageSource.camera, 'aadhaar');
                                              Navigator.pop(context);
                                            },
                                          ),
                                          SizedBox(height: 20),
                                          GestureDetector(
                                            child: Text('Gallery'),
                                            onTap: () {
                                              _getImage(ImageSource.gallery, 'aadhaar');
                                              Navigator.pop(context);
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                              icon: Icon(Icons.file_upload),
                              label: Text('Upload Aadhaar Card'),
                            ),
                  
                ),
              
              Form(
                
                key: detailformkey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                        padding: EdgeInsets. fromLTRB(0, 30, 0, 0),
                        alignment: Alignment.center,
                        child: ElevatedButton(
                           
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.lightBlue[800],
                          ),
                          child: Text('Submit'),
                          onPressed: () {
                            
                            _performLogin();
                          },
                        ),
                      ),
                
                ]
  ),
  ),
  
          ],
          ),
                      ),
            ),
                    ],
                    
  ),
  ),
              );
        
      

    
  }
} 