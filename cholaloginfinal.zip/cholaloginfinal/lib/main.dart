// ignore_for_file: unnecessary_new, use_key_in_widget_constructors, prefer_const_constructors, unused_label, must_be_immutable, deprecated_member_use, avoid_print

import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
      home: Home(),
      theme: new ThemeData(scaffoldBackgroundColor: const Color(0xFFCFD8DC)),
    ));

class Home extends StatelessWidget {
  var userid = '';
  var password = '';
  final loginFormKey = GlobalKey<FormState>();
  final logincontroller = TextEditingController(text: "User");
  final pwdcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white,
        title: Image.asset('assets/cholalogo.jpg',
            fit: BoxFit.contain, height: 50),
      ),
      body: SingleChildScrollView(
        child: Container(
          
          child:
      Column(
        children: [
          Container(
              color: Colors.indigo[900],
              height: 50.0,
              width: double.infinity,
              padding: EdgeInsets.fromLTRB(170.0, 13.0, 5.0, 10.0),
              child: Text(
                'Login',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                ),
              )),
          const Divider(
            color: Colors.red,
            height: 0,
            thickness: 2,
            indent: 0,
            endIndent: 0,
          ),
          Container(
            height: 500.0,
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(20, 100, 20, 30),
            color: Colors.white,
            child: Form(
                key: loginFormKey,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      TextFormField(
                        controller: logincontroller,
                        decoration: const InputDecoration(
                          icon: const Icon(Icons.person),
                          hintText: 'Enter User ID',
                          labelText: 'User ID',
                          border: OutlineInputBorder()
                        ),
                        validator: (value) {  
                          if (value!.isEmpty) {  
                            return 'User ID is required';  
                          }  
                          return null;  
                          },  
                      ),
                      SizedBox(height: 25.0),
                      TextFormField(
                        obscureText: true,
                        controller: pwdcontroller,
                        decoration: const InputDecoration(
                          icon: const Icon(Icons.password),
                          hintText: 'Enter password',
                          labelText: 'Password',
                          border: OutlineInputBorder()
                        ),
                        validator: (value) {  
                          if (value!.isEmpty) {  
                            return 'Password required';  
                          }  
                          return null;  
                          }, 
                      ),
                      new Container(
                          padding:
                              const EdgeInsets.only(left: 150.0, top: 50.0),
                          child: new ElevatedButton(
                             style: ElevatedButton.styleFrom(
                              primary: Colors.lightBlue[800],
                             ),
                            child: Text('Login'),
                            onPressed: (){
                              print("button pressed");
                              print(logincontroller.value.text);
                              print(pwdcontroller.value.text);
                               if (loginFormKey.currentState!.validate()){    
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login Successful')));}
                  
  })),
                    ])),
          ),
          Container(
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.fromLTRB(10, 50, 10, 10),
                  child: Column(
                    children: [
                      Text(
                        'About CHOLA| Contact us| Privacy Policy| Terms & Conditions|',
                        textAlign: TextAlign.center,
                      ),
                      Text(
                        '© Copyright 2023 Cholamandalam. All Rights Reserved.',
                        textAlign: TextAlign.center,
                      ),
                      Text(
                        'Version 0_648 on Sat May 06 2023',
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              ],
            )
          )
        ],
      ),
    ),
      ),
      );
  }
}
