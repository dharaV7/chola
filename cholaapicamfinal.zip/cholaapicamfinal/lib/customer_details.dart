import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';


void main() => runApp(MaterialApp(
   home: MyApp(),
));

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  final detailformkey = GlobalKey<FormState>();

  final fnamecontroller = TextEditingController(text: "First Name");

  final lnamecontroller = TextEditingController(text: "Last Name");

  File? _image;




  Future<void> _getImage(ImageSource source) async {
    final pickedImage = await ImagePicker().getImage(source: source);
    if (pickedImage != null) {
      setState(() {
        _image = File(pickedImage.path);
      });
    }
  }

  Future<void> _storeImage(File imageFile) async {
    final directory = await getTemporaryDirectory();
    final imagePath = '${directory.path}/my_image.jpg';
    await imageFile.copy(imagePath);
    // You now have the image stored in the temporary directory
  }

   void _performLogin() {
    if (detailformkey.currentState!.validate()) {
      if (_image == null) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Upload Profile Photo'),
            content: Text('Please upload a profile photo.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _getImage(ImageSource.gallery);
                },
                child: Text('Gallery'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _getImage(ImageSource.camera);
                },
                child: Text('Camera'),
              ),
            ],
          ),
        );
      } else if(detailformkey.currentState!.validate()) {
    // Perform login logic here
    String firstName = fnamecontroller.text;
    String lastName = lnamecontroller.text;
    print('Logged in: $firstName $lastName');
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Submitted'),
        content: Text('Form submitted successfully!'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

      
    }
  }

   @override
  void dispose() {
    fnamecontroller.dispose();
    lnamecontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
          return Scaffold(
            
          appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.white,
          title: Image.asset(
            'assets/cholalogo.jpg',
            fit: BoxFit.contain,
            height: 50,
          ),
        ),
        body: 
         SingleChildScrollView(
          
          child: Column(
          
          children: [
            Container(
              color: Colors.indigo[900],
              height: 50.0,
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(110, 13.0, 5.0, 10.0),
              child: const Text(
                'Customer Details',
                
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                ),
              ),
            ),
            
            const Divider(
              color: Colors.red,
              height: 0,
              thickness: 2,
              indent: 0,
              endIndent: 0,
            ),
           
            SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 100, 20, 30),
               child: Column(children: [
                InkWell(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Choose an option'),
                        content: SingleChildScrollView(
                          child: ListBody(
                            children: [
                              GestureDetector(
                                child: Text('Camera'),
                                onTap: () {
                                  _getImage(ImageSource.camera);
                                  Navigator.pop(context);
                                  
                                },
                              ),
                              SizedBox(height: 20),
                              GestureDetector(
                                child: Text('Gallery'),
                                onTap: () {
                                  _getImage(ImageSource.gallery);
                                  Navigator.pop(context);
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                  child: CircleAvatar(
                    backgroundImage: _image != null
                        ? FileImage(_image!)
                        : AssetImage('assets/profile.jpg') as ImageProvider,
                    radius: 80,
                  ),
                  
                ),
              
              Form(
                
                key: detailformkey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 50),
                    TextFormField(
                      controller: fnamecontroller,
                      decoration: const InputDecoration(
                        
                        hintText: 'Enter First Name',
                        labelText: 'First Name',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'First Name is required';
                      }
                        return null;

  }
  ),
                    SizedBox(height: 30),
                    TextFormField(
                      
                      controller: lnamecontroller,
                      decoration: const InputDecoration(
                        
                        hintText: 'Enter Last Name',
                        labelText: 'Last Name',
                        border: OutlineInputBorder(),
                        ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Last Name is required';
                        }return null;}
                ),
                    Container(
                        padding: EdgeInsets. fromLTRB(0, 30, 0, 0),
                        alignment: Alignment.center,
                        child: ElevatedButton(
                           
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.lightBlue[800],
                          ),
                          child: Text('Submit'),
                          onPressed: () {
                            _performLogin();
                          },
                        ),
                      ),
                
                ]
  ),
  ),
  
          ],
          ),
                      ),
            ),
                    ],
                    
  ),
  ),
              );
        
      

    
  }
}
