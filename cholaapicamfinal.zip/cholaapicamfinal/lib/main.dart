

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'customer_details.dart';


void main() => runApp(MaterialApp(
      home: Home(),
    ));

class Home extends StatefulWidget {
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  var userid = '';

  var password = '';

  final loginFormKey = GlobalKey<FormState>();

  final logincontroller = TextEditingController(text: "User");

  final pwdcontroller = TextEditingController();

  Future<void> login(BuildContext context) async {
    final String userID = logincontroller.text.trim();
    final String password = pwdcontroller.text.trim();
    print("Entered to login fn");
    // Make API request
    final Uri uri = Uri.parse(
        'https://wapleap1.chola.murugappa.com/usermanagementapi/auth/authenticate?module=collections');
    final Map<String, String> body = {'userId': userID, 'password': password};

    final response = await http.post(uri, body: body);

    if (response.statusCode == 200) {
      // Login successful
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Login Successful'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      // Login failed
      showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Login Failed'),
        content: Text('Invalid User Credentials'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close the dialog
            },
            child: Text('OK'),
          ),
        ],
      );
    },
  );
    }
  }

  bool obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white,
        title: Image.asset(
          'assets/cholalogo.jpg',
          fit: BoxFit.contain,
          height: 50,
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Container(
                color: Colors.indigo[900],
                height: 50.0,
                width: double.infinity,
                padding: EdgeInsets.fromLTRB(160.0, 13.0, 5.0, 10.0),
                child: Text(
                  'Login',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
              ),
              const Divider(
                color: Colors.red,
                height: 0,
                thickness: 2,
                indent: 0,
                endIndent: 0,
              ),
              Container(
                height: 500.0,
                width: double.infinity,
                padding: EdgeInsets.fromLTRB(20, 100, 20, 30),
                color: Colors.white,
                child: Form(
                  key: loginFormKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      TextFormField(
                        controller: logincontroller,
                        decoration: InputDecoration(
                          icon: Icon(Icons.person),
                          hintText: 'Enter User ID',
                          labelText: 'User ID',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          
                          if (value!.isEmpty) {
                            return 'User ID is required';
                          }else if(value.length<=6){
                            return 'User ID must be atleast 6 characters';
                          }else if(!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]").hasMatch(value)){
                            return 'Enter a valid email';
                          }
                          return null;
                        
  }),
                      
                      SizedBox(height: 25.0),
                      TextFormField(
                        obscureText: obscurePassword,
                        controller: pwdcontroller,
                        decoration: InputDecoration(
                          icon: Icon(Icons.password),
                          hintText: 'Enter password',
                          labelText: 'Password',
                          border: OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: Icon(
                              obscurePassword ? Icons.visibility_off : Icons.visibility,
                            ),
                            onPressed: () {
                              setState((){
                                obscurePassword = !obscurePassword;
                              });                              
                            },
                          )
                        ),
                        
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Password required';
                          }else if(value.length<=8){
                            return 'Password must be atleast 8 characters';
                          }
                          return null;
                        },
                      ),
                      new Container(
                        
                        padding: const EdgeInsets.only(left: 140.0, top: 50.0),
                        child: new ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Colors.lightBlue[800],
                          ),
                          child: Text('Login'),
                          onPressed: () {
                            print("button pressed");
                            print(logincontroller.value.text);
                            print(pwdcontroller.value.text);
                            if (loginFormKey.currentState!.validate()) {
                            login(context);
                            Navigator.push(context, MaterialPageRoute(builder:(context)=> MyApp()));
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                  child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 50, 10, 10),
                    child: Column(
                      children: [
                        Text(
                          'About CHOLA| Contact us| Privacy Policy| Terms & Conditions|',
                          textAlign: TextAlign.center,
                        ),
                        Text(
                          '© Copyright 2023 Cholamandalam. All Rights Reserved.',
                          textAlign: TextAlign.center,
                        ),
                        Text(
                          'Version 0_648 on Sat May 06 2023',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  )
                ],
              ))
            ],
          ),
        ),
      ),
    );
  }
}
